from django.apps import AppConfig


class MedicalrecordsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medicalrecords'
