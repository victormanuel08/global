
from .cities import *
from .diagnoses import *
from .records import *
from .thirds import *
from .specialities import *
from .scheduled import *



