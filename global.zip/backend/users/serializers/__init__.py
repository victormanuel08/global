from .group import *
from .permission import *
from .user import *

from medicalrecords.serializers import *