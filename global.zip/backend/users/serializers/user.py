from rest_framework import serializers
from users.models import User, PermissionsSet
from medicalrecords.models import Thirds
from medicalrecords.serializers import ThirdSerializer


class UserSerializer(serializers.ModelSerializer):
    third = serializers.SerializerMethodField()
    menu_items = serializers.SerializerMethodField()

    def get_third(self, obj):
        thirds = Thirds.objects.filter(user=obj)
        if thirds.exists():
            return ThirdSerializer(thirds.first()).data
        else:
            return None

    def get_menu_items(self, obj):
        groups = obj.groups.all()
        gd = [group.groupdetails.id for group in groups]
        ps = PermissionsSet.objects.filter(groups__in=gd).order_by("id").distinct()
        return [
            {
                "path": p.path,
                "icon": p.icon,
                "order_index": p.order_index,
                "label": p.label,
            }
            for p in ps
        ]

        # return [g.name for g in groupsdetails]

    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "email",
            "first_name",
            "last_name",
            "is_active",
            "is_staff",
            "is_superuser",
            "menu_items",
            "third",
        ]
