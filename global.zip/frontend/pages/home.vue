<template>
    
    <div>
        Página de inicio
    </div>
</template>