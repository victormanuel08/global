<template>
    <div>
        <h1>Mi Ubicación</h1>

    </div>
</template>

<script setup>
import useGeoLocation from '~/composables/geoLocation';

</script>