<template>
    <div class="flex gap-3 bg-gray-100 border" style="height: calc(100vh - 48px) !important">
        <!-- Barra lateral -->
        <div class="w-48 bg-gray-100 hidden md:block">
            <div class="py-5 text-center">
                <img src="@/assets/img/GLOBALIPS.PNG" alt="GLOBAL" class="object-contain w-full md:w-1/1 lg:w-1/1">
            </div>
            <div class="flex flex-col gap-3 m-2">
                <UButton :to="item.path" v-for="item in menuItems" class="rounded-full" :icon="item.icon">
                    {{ item.label }}
                </UButton>

            </div>
        </div>

        <!-- Contenido principal -->
        <div class="flex-grow bg-white border overflow-auto rounded-lg">
            <!-- Menú a la derecha (visible solo en pantallas grandes) -->
            <div class="p-2 bg-gray-100 rounded-full shadow m-4 text-right hidden md:block">
                {{ user.username }} {{ user.first_name }} {{ user.last_name }}
                <UButton @click="doLogout">Cerrar sesión</UButton>
            </div>

            <div class="p-2 bg-gray-100 rounded-full shadow m-4 text-left block md:hidden">
                <UButton :to="item.path" v-for="item in menuItems" class="rounded-full" :icon="item.icon">
                    {{ item.label }}
                </UButton>
            </div>


            <slot></slot>
        </div>
    </div>
</template>

<script setup lang="ts">

const authUserStorage = useAuthUserStorage()
const authTokensStorage = useAuthTokensStorage()
const user = computed(() => authUserStorage.value)
const tokenCookie = useCookie('token')

const menuItems = computed(() => {
    const user = authUserStorage.value
    if (!user) return []
    return user.menu_items
})

const doLogout = () => {
    tokenCookie.value = null
    authUserStorage.value = {}
    authTokensStorage.accessToken.value = null
    authTokensStorage.refreshToken.value = null
    useRouter().push('/')
}

</script>

<style scoped>
/* Estilos específicos para este componente */
</style>
