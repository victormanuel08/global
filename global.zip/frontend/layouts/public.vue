<template>
    <div class="h-screen bg-gradient-to-r from-white to-indigo-600">
        <slot></slot>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>