export default defineAppConfig({
    ui: {
        primary: 'blue',
        gray: 'cool'
      }
})